disable

function setupUI() {
    let overlaymarkerTable = Vars.ui.hudGroup.find("statustable");
    overlaymarkerTable.row();

    let tab = new Table();
    overlaymarkerTable.add(tab).bottom().left();

    tab.table(Tex.pane, t => {
        let b = new Button(Styles.none);
        let icon = new TextureRegionDrawable(Blocks.copperWall.uiIcon);
        b.button(icon, () => {

        });
        t.add(b);

        t.clicked(() => {
            Vars.ui.showTextInput("", "Cheat", 32768, "", false, text => {
            })
        })
    })

    tab.visibility = () => {
        return (Vars.ui.hudfrag.shown && !Vars.net.client() ? true : false)
    }
}

Events.on(ClientLoadEvent, () => {
    setupUI()
})